#include <SPI.h>
#include "Tetris.h"
#define SS_PIN 10
unsigned long lastClickTimeTetris;
byte contadorTetris = 0;
void load_tetris()
{
  lcd.clear();
  // put your setup code here, to run once:
  lcd.print("   Score: 0");
  Serial.begin(9600);
  randomSeed(analogRead(0));
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }
  Serial.println("Loading ...");
  Dp_Init();
  Te_Init();
  Serial.println(random(9, 15) * (10 + pow(3, 1) * 10));
  Serial.println(random(9, 15) * (10 + pow(3, 2) * 10));
  Serial.println(random(9, 15) * (10 + pow(3, 3) * 10));
  Serial.println(random(9, 15) * (10 + pow(3, 4) * 10));
}



byte xC = 0;
byte yC = 0;
long frameCount = 0;

bool loop_tetris() {
  // put your main code here, to run repeatedly:
  // Detectar el clic del botón
  if (digitalRead(SW) == 0) {
    unsigned long currentTime = millis();  // Obtener el tiempo actual
    // Verificar si ha pasado menos de 3000 ms desde el último clic
    if (currentTime - lastClickTimeTetris < 3000) {
      contadorTetris++; 
      if (contadorTetris >= 50) {
        contadorTetris = 0;
        Te_Reload();
        delay(500);
        return false;
      }
    } else {
      contadorTetris = 1; 
    }
    lastClickTimeTetris = currentTime; 
  }
  frameCount++;
  Te_Draw();
  Te_Update(frameCount);
  delay(1);
  return true;
}
